<?php
    include "connection.php";
    $id =$_GET['id'];
    $tanggal =$_GET['tanggal'];
    $kabupatenId =$_GET['kabupatenId'];
    $positif =$_GET['positif'];
    $dirawat =$_GET['dirawat'];
    $sembuh =$_GET['sembuh'];
    $meninggal =$_GET['meninggal'];

    $getTanggal = $koneksi->query("SELECT tanggal FROM tb_data WHERE id='$id'");
    while ($rowData = mysqli_fetch_array($getTanggal)) {
        $row[] = $rowData;
    }

    $finalEdit = $koneksi->query("UPDATE tb_data set positif='$positif', dirawat='$dirawat', sembuh='$sembuh', meninggal= '$meninggal' WHERE id='$id'");
    print json_encode($row);

?>