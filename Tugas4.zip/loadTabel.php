<?php
    include "connection.php";
    $tanggal =$_GET['tgl'];
    if (empty($tanggal)){
    	$queryGetData = $koneksi->query("SELECT id, nama_kabupaten, positif, dirawat, sembuh, meninggal FROM tb_data 
                                    JOIN tb_kabupaten ON tb_kabupaten.`id_kabupaten` = tb_data.`id_kabupaten`
                                    WHERE tanggal = (SELECT tanggal FROM tb_data ORDER BY tanggal DESC LIMIT 1)");
    }else{
    	$queryGetData = $koneksi->query("SELECT id, nama_kabupaten, positif, dirawat, sembuh, meninggal FROM tb_data 
                                    JOIN tb_kabupaten ON tb_kabupaten.`id_kabupaten` = tb_data.`id_kabupaten`
                                    WHERE tanggal = '$tanggal'");
    }
    
    
    while ($rowData = mysqli_fetch_array($queryGetData)) {
        $row[] = $rowData;
    }
    
    print json_encode($row);
?>